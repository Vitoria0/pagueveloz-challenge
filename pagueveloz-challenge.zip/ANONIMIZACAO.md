# Guia de Anonimização do Projeto

Este documento descreve os passos para remover todas as informações pessoais antes de enviar a solução.

## 🧹 Limpeza Automática

Execute o script de limpeza:

```powershell
.\cleanup.ps1
```

## 📋 Checklist Manual

### 1. Arquivos a Remover/Verificar

- [ ] **Logs**: Remover todos os arquivos `.log` e diretórios `logs/`
- [ ] **Build artifacts**: Remover `bin/` e `obj/` de todos os projetos
- [ ] **Cache do NuGet**: Remover `.nuget/` se existir
- [ ] **Arquivos temporários**: Remover `.user`, `.suo`, `.userosscache`

### 2. Arquivos de Configuração

- [ ] **.git/config**: Verificar e remover informações de `user.name` e `user.email`
- [ ] **appsettings.Development.json**: Verificar se não contém informações pessoais
- [ ] **launchSettings.json**: Verificar se não contém caminhos pessoais

### 3. Código e Documentação

- [ ] **README.md**: Remover seção de autor/informações pessoais
- [ ] **Comentários no código**: Verificar se há comentários com informações pessoais
- [ ] **Namespaces**: Verificar se não contêm informações identificáveis

### 4. Metadados

- [ ] **AssemblyInfo.cs**: Verificar se não contém informações de autoria
- [ ] **XML Documentation**: Verificar arquivos `.xml` gerados

## 🔍 Verificação

### Buscar informações pessoais no código:

```powershell
# Buscar nomes de usuário
Get-ChildItem -Recurse -Include *.cs,*.md,*.json,*.yml | Select-String -Pattern "Vitoria|Machado|NB019628" -CaseSensitive:$false

# Buscar caminhos pessoais
Get-ChildItem -Recurse -Include *.cs,*.md,*.json,*.yml | Select-String -Pattern "C:\\Users\\" -CaseSensitive:$false
```

## 📦 Criar Arquivo ZIP Anonimizado

Após a limpeza, crie o arquivo ZIP:

```bash
git archive --format=zip --output=./pagueveloz-challenge.zip HEAD
```

Ou se não estiver usando Git:

```powershell
# Criar ZIP excluindo arquivos desnecessários
Compress-Archive -Path src,tests,*.sln,*.md,Dockerfile,docker-compose.yml,.gitignore,.gitattributes -DestinationPath pagueveloz-challenge.zip -Force
```

## ✅ Verificação Final

Antes de enviar, verifique:

1. ✅ Não há arquivos de log
2. ✅ Não há binários ou arquivos de build
3. ✅ Não há informações pessoais no README
4. ✅ Não há caminhos pessoais nos arquivos
5. ✅ Não há informações de autoria nos metadados
6. ✅ O arquivo ZIP não contém informações pessoais

## 🚫 Arquivos que NÃO devem ser incluídos

- `bin/` e `obj/` (arquivos de build)
- `logs/` e `*.log` (arquivos de log)
- `.vs/` e `.vscode/` (configurações do editor)
- `node_modules/` (se houver)
- Arquivos temporários do sistema
- Arquivos de cache

## 📝 Notas

- O script `cleanup.ps1` remove automaticamente a maioria dos arquivos desnecessários
- Sempre revise manualmente antes de enviar
- Mantenha apenas o código-fonte, testes, documentação e arquivos de configuração essenciais

