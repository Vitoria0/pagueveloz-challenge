# Quick Start Guide

## ✅ Status Atual

O Docker Compose foi executado com sucesso! Os containers estão rodando:

- **PostgreSQL**: `pagueveloz-postgres` (porta 5432)
- **API**: `pagueveloz-api` (porta 5000)

## 🚀 Acessar a API

### Swagger UI
Abra no navegador: http://localhost:5000/swagger

### Health Check
```bash
curl http://localhost:5000/health
```

### Métricas Prometheus
```bash
curl http://localhost:5000/metrics
```

## 📝 Criar Migração do Banco de Dados

Para criar a primeira migração do banco de dados, execute:

```bash
# Entrar no container da API
docker-compose exec api bash

# Dentro do container, executar:
cd /app
dotnet ef migrations add InitialCreate --project /src/src/PagueVeloz.TransactionProcessor.Infrastructure --startup-project /src/src/PagueVeloz.TransactionProcessor.Api

# Aplicar migração
dotnet ef database update --project /src/src/PagueVeloz.TransactionProcessor.Infrastructure --startup-project /src/src/PagueVeloz.TransactionProcessor.Api
```

**OU** execute localmente (se tiver .NET SDK instalado):

```bash
# Instalar ferramentas EF Core (se necessário)
dotnet tool install --global dotnet-ef

# Navegar para o projeto API
cd src/PagueVeloz.TransactionProcessor.Api

# Criar migração
dotnet ef migrations add InitialCreate --project ../PagueVeloz.TransactionProcessor.Infrastructure

# Aplicar migração
dotnet ef database update --project ../PagueVeloz.TransactionProcessor.Infrastructure
```

## 🧪 Testar a API

### Criar uma Conta

```bash
curl -X POST http://localhost:5000/api/accounts \
  -H "Content-Type: application/json" \
  -d '{
    "clientId": "CLI-001",
    "initialBalance": 0,
    "creditLimit": 50000
  }'
```

### Criar uma Transação (Crédito)

```bash
curl -X POST http://localhost:5000/api/transactions \
  -H "Content-Type: application/json" \
  -d '{
    "operation": 1,
    "accountId": "ACC-001",
    "amount": 100000,
    "currency": "BRL",
    "referenceId": "TXN-001"
  }'
```

## 📊 Ver Logs

```bash
# Logs da API
docker-compose logs -f api

# Logs do PostgreSQL
docker-compose logs -f postgres
```

## 🛑 Parar os Containers

```bash
docker-compose down
```

## 🔄 Reiniciar os Containers

```bash
docker-compose restart
```

## 🗑️ Limpar Tudo (incluindo volumes)

```bash
docker-compose down -v
```

