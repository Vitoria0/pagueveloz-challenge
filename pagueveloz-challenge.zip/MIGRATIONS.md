# Migrações do Banco de Dados

## Aplicar Migrações

### Usando EF Core CLI

```bash
# Instalar ferramentas EF Core (se ainda não tiver)
dotnet tool install --global dotnet-ef

# Navegar para o projeto API
cd src/PagueVeloz.TransactionProcessor.Api

# Criar uma nova migração
dotnet ef migrations add InitialCreate --project ../PagueVeloz.TransactionProcessor.Infrastructure

# Aplicar migrações ao banco de dados
dotnet ef database update --project ../PagueVeloz.TransactionProcessor.Infrastructure
```

### Usando Docker

As migrações são aplicadas automaticamente quando a aplicação inicia (ver `Program.cs`).

### Estrutura do Banco de Dados

O banco de dados contém as seguintes tabelas:

- **Clients**: Armazena informações dos clientes
- **Accounts**: Armazena informações das contas (com controle de concorrência otimista)
- **Transactions**: Armazena todas as transações financeiras (com índice único em ReferenceId)

### Notas

- O campo `ReferenceId` na tabela `Transactions` possui índice único para garantir idempotência
- Os campos `Balance` e `ReservedBalance` na tabela `Accounts` são marcados como `IsConcurrencyToken()` para controle de concorrência otimista

