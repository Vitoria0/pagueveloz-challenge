# Guia de Solução de Problemas

## 🔴 Erro: Porta já em uso (Port 5000 already in use)

### Solução 1: Parar o container Docker
```bash
docker-compose stop api
# ou
docker-compose down
```

### Solução 2: Usar porta diferente (já configurado)
A aplicação local agora usa a porta **5002** por padrão. Acesse:
- http://localhost:5002/swagger

## 🔴 Erro: Autenticação PostgreSQL falhou

### Problema
```
autenticação do tipo senha falhou para o usuário "postgres"
```

### Soluções

#### Opção 1: Usar PostgreSQL do Docker (Recomendado)
O Docker Compose já está configurado com PostgreSQL. Certifique-se de que está rodando:

```bash
# Verificar se o PostgreSQL está rodando
docker-compose ps postgres

# Se não estiver, iniciar
docker-compose up -d postgres
```

A string de conexão já está configurada para usar o PostgreSQL do Docker:
```
Host=localhost;Port=5432;Database=pagueveloz_db;Username=postgres;Password=postgres
```

#### Opção 2: Usar PostgreSQL Local
Se você tem PostgreSQL instalado localmente com credenciais diferentes, edite `appsettings.Development.json`:

```json
{
  "ConnectionStrings": {
    "DefaultConnection": "Host=localhost;Port=5432;Database=pagueveloz_db;Username=SEU_USUARIO;Password=SUA_SENHA"
  }
}
```

#### Opção 3: Desabilitar Migrações Automáticas
Se você não quer aplicar migrações automaticamente, comente a seção de migrações no `Program.cs` e execute manualmente:

```bash
cd src/PagueVeloz.TransactionProcessor.Api
dotnet ef database update --project ../PagueVeloz.TransactionProcessor.Infrastructure
```

## 🔴 Erro: Modelo tem mudanças pendentes

### Solução
Crie uma nova migração:

```bash
cd src/PagueVeloz.TransactionProcessor.Api
dotnet ef migrations add InitialCreate --project ../PagueVeloz.TransactionProcessor.Infrastructure
dotnet ef database update --project ../PagueVeloz.TransactionProcessor.Infrastructure
```

## ✅ Executar Localmente vs Docker

### Executar Localmente (Desenvolvimento)
```bash
# 1. Certifique-se que o PostgreSQL do Docker está rodando
docker-compose up -d postgres

# 2. Execute a aplicação
cd src/PagueVeloz.TransactionProcessor.Api
dotnet run
```

Acesse: http://localhost:5002/swagger

### Executar com Docker (Produção/Teste)
```bash
# Iniciar tudo
docker-compose up -d

# Ver logs
docker-compose logs -f api
```

Acesse: http://localhost:5000/swagger

## 🔧 Verificar Status dos Serviços

```bash
# Ver containers rodando
docker-compose ps

# Ver logs da API
docker-compose logs api

# Ver logs do PostgreSQL
docker-compose logs postgres

# Verificar se PostgreSQL está acessível
docker-compose exec postgres psql -U postgres -d pagueveloz_db -c "SELECT version();"
```

## 🗑️ Limpar e Reiniciar

```bash
# Parar tudo
docker-compose down

# Parar e remover volumes (apaga dados do banco)
docker-compose down -v

# Rebuild e iniciar
docker-compose up -d --build
```

## 📝 Verificar Portas em Uso

### Windows (PowerShell)
```powershell
netstat -ano | findstr :5000
netstat -ano | findstr :5432
```

### Linux/Mac
```bash
lsof -i :5000
lsof -i :5432
```

## 🔍 Verificar Configuração do Banco

```bash
# Testar conexão com PostgreSQL do Docker
docker-compose exec postgres psql -U postgres -c "\l"

# Verificar se o banco existe
docker-compose exec postgres psql -U postgres -c "SELECT datname FROM pg_database WHERE datname = 'pagueveloz_db';"
```

