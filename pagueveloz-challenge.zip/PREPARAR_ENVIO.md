# Preparação para Envio da Solução

## 🧹 Passo 1: Executar Limpeza Automática

Execute o script de limpeza para remover arquivos desnecessários:

```powershell
.\cleanup.ps1
```

## 🔍 Passo 2: Verificação Manual

### Verificar se há informações pessoais:

```powershell
# Buscar nomes de usuário ou informações pessoais
Get-ChildItem -Recurse -Include *.cs,*.md,*.json,*.yml,*.yaml,*.ps1 | 
    Select-String -Pattern "Vitoria|Machado|NB019628|C:\\Users\\" -CaseSensitive:$false |
    Select-Object Path, LineNumber, Line
```

### Verificar arquivos de configuração do Git:

```powershell
# Se existir .git/config, verificar informações pessoais
if (Test-Path ".git\config") {
    Get-Content ".git\config" | Select-String -Pattern "name|email"
}
```

## 📦 Passo 3: Criar Arquivo ZIP

### Opção 1: Usando Git (Recomendado)

Se você inicializou um repositório Git:

```bash
git archive --format=zip --output=./pagueveloz-challenge.zip HEAD
```

### Opção 2: Usando PowerShell

Se não estiver usando Git:

```powershell
# Criar ZIP excluindo arquivos desnecessários
$filesToInclude = @(
    "src",
    "tests",
    "*.sln",
    "*.md",
    "Dockerfile",
    "docker-compose.yml",
    ".gitignore",
    ".gitattributes"
)

Compress-Archive -Path $filesToInclude -DestinationPath pagueveloz-challenge.zip -Force
```

## ✅ Passo 4: Checklist Final

Antes de enviar, verifique:

- [ ] ✅ Todos os arquivos de log foram removidos
- [ ] ✅ Todos os diretórios `bin/` e `obj/` foram removidos
- [ ] ✅ Não há informações pessoais no README.md
- [ ] ✅ Não há caminhos pessoais nos arquivos de código
- [ ] ✅ Não há informações de autoria nos metadados
- [ ] ✅ O arquivo ZIP foi criado com sucesso
- [ ] ✅ O arquivo ZIP não contém informações pessoais

## 🚀 Passo 5: Enviar para GitHub (Opcional)

Se você quiser usar Git:

```bash
# Inicializar repositório (se ainda não foi feito)
git init

# Adicionar remote
git remote add origin https://github.com/Vitoria0/pagueveloz-challenge.git

# Adicionar arquivos
git add .

# Commit
git commit -m "Initial commit - PagueVeloz Transaction Processor"

# Push (se quiser enviar para o GitHub)
git push -u origin main
```

## 📝 Notas Importantes

1. **Nunca commite**:
   - Arquivos de log (`*.log`, `logs/`)
   - Arquivos de build (`bin/`, `obj/`)
   - Arquivos de configuração pessoal (`.user`, `.suo`)
   - Informações de autoria

2. **Sempre revise** o arquivo ZIP antes de enviar

3. **Mantenha apenas**:
   - Código-fonte (`.cs`)
   - Testes (`.cs` em `tests/`)
   - Documentação (`.md`)
   - Arquivos de configuração do projeto (`.csproj`, `.sln`)
   - Docker files (`Dockerfile`, `docker-compose.yml`)
   - Arquivos de configuração do Git (`.gitignore`, `.gitattributes`)

## 🔒 Segurança

- Não inclua senhas ou credenciais nos arquivos
- Use variáveis de ambiente para informações sensíveis
- Revise `appsettings.json` e `appsettings.Development.json`

