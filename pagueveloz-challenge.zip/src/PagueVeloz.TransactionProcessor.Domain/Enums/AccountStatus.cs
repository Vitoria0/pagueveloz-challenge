namespace PagueVeloz.TransactionProcessor.Domain.Enums;

public enum AccountStatus
{
    Active = 1,
    Inactive = 2,
    Blocked = 3
}

