namespace PagueVeloz.TransactionProcessor.Domain.Enums;

public enum TransactionStatus
{
    Success = 1,
    Failed = 2,
    Pending = 3
}

