# Solução: Aplicar Migrações

## ✅ Migração Criada com Sucesso!

A migração `InitialCreate` foi criada com sucesso em:
```
src/PagueVeloz.TransactionProcessor.Infrastructure/Migrations/
```

## 🔧 Aplicar Migração ao Banco de Dados

### Opção 1: Usando o PostgreSQL do Docker (Recomendado)

1. **Certifique-se que o PostgreSQL do Docker está rodando:**
```bash
docker-compose up -d postgres
```

2. **Aplique a migração:**
```bash
cd src/PagueVeloz.TransactionProcessor.Api
dotnet ef database update --project ../PagueVeloz.TransactionProcessor.Infrastructure --context ApplicationDbContext
```

### Opção 2: Aplicar via Docker (se houver erro de autenticação local)

Se você tem PostgreSQL local instalado na porta 5432 com credenciais diferentes, você pode:

1. **Aplicar a migração dentro do container:**
```bash
docker-compose exec api bash
cd /app
dotnet ef database update --project /src/src/PagueVeloz.TransactionProcessor.Infrastructure --startup-project /src/src/PagueVeloz.TransactionProcessor.Api
```

2. **OU usar uma porta diferente para o PostgreSQL local:**
   - Pare o PostgreSQL local
   - Ou altere a porta do Docker Compose

### Opção 3: Aplicar Automaticamente na Inicialização

A aplicação já está configurada para tentar aplicar migrações automaticamente na inicialização. Se houver erro, ela continuará funcionando, mas você precisará aplicar manualmente.

## ✅ Verificar se Migração foi Aplicada

```bash
# Verificar tabelas criadas
docker-compose exec postgres psql -U postgres -d pagueveloz_db -c "\dt"

# Verificar histórico de migrações
docker-compose exec postgres psql -U postgres -d pagueveloz_db -c "SELECT * FROM \"__EFMigrationsHistory\";"
```

## 🔍 Troubleshooting

### Erro: "autenticação do tipo senha falhou"

Isso significa que há um PostgreSQL local rodando na porta 5432 com credenciais diferentes.

**Soluções:**

1. **Parar PostgreSQL local:**
   - Windows: Services → PostgreSQL → Stop
   - Ou use outra porta no Docker Compose

2. **Usar PostgreSQL do Docker:**
   - Certifique-se que `docker-compose ps postgres` mostra o container rodando
   - A string de conexão já está configurada para `postgres/postgres`

3. **Alterar credenciais no appsettings.Development.json:**
   - Se você tem PostgreSQL local, atualize a string de conexão com suas credenciais

## 📝 Status Atual

- ✅ Migração criada: `InitialCreate`
- ⚠️ Migração ainda não aplicada (erro de autenticação)
- ✅ Aplicação rodando na porta 5002
- ✅ PostgreSQL Docker rodando na porta 5432

## 🚀 Próximos Passos

1. Resolver o problema de autenticação (escolha uma das opções acima)
2. Aplicar a migração
3. Testar a API em http://localhost:5002/swagger

