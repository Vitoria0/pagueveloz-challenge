# Como Iniciar a Aplicação

## 🚀 Opção 1: Executar Localmente (Recomendado para Desenvolvimento)

### Passo 1: Certifique-se que o PostgreSQL do Docker está rodando
```bash
docker-compose up -d postgres
```

### Passo 2: Execute a aplicação
```bash
cd src/PagueVeloz.TransactionProcessor.Api
dotnet run
```

### Passo 3: Acesse o Swagger
Abra no navegador: **http://localhost:5002/swagger**

## 🐳 Opção 2: Executar com Docker Compose

### Passo 1: Iniciar todos os serviços
```bash
docker-compose up -d
```

### Passo 2: Verificar logs
```bash
docker-compose logs -f api
```

### Passo 3: Acesse o Swagger
Abra no navegador: **http://localhost:5000/swagger**

## ⚠️ Solução de Problemas

### Erro: "network not found"
```bash
# Limpar redes órfãs
docker network prune -f

# Reiniciar containers
docker-compose down
docker-compose up -d
```

### Swagger não aparece
1. Verifique se a aplicação está rodando:
   ```bash
   # Local
   netstat -ano | findstr :5002
   
   # Docker
   docker-compose ps
   ```

2. Verifique os logs:
   ```bash
   # Local - veja o terminal onde executou dotnet run
   # Docker
   docker-compose logs api
   ```

3. Acesse a URL correta:
   - Local: http://localhost:5002/swagger
   - Docker: http://localhost:5000/swagger

### Porta já em uso
Se a porta 5002 estiver em uso localmente:
- Pare outros processos na porta
- Ou altere a porta no `launchSettings.json`

## 📝 URLs Importantes

### Execução Local (porta 5002)
- Swagger UI: http://localhost:5002/swagger
- Health Check: http://localhost:5002/health
- Métricas: http://localhost:5002/metrics

### Execução Docker (porta 5000)
- Swagger UI: http://localhost:5000/swagger
- Health Check: http://localhost:5000/health
- Métricas: http://localhost:5000/metrics

## ✅ Verificar se está funcionando

```bash
# Teste rápido com curl
curl http://localhost:5002/health

# Ou no navegador
http://localhost:5002/health
```

Se retornar `Healthy`, a aplicação está funcionando!

