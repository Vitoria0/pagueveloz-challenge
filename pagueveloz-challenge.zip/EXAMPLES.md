# Exemplos de Uso da API

## Criar uma Conta

```bash
curl -X POST http://localhost:5000/api/accounts \
  -H "Content-Type: application/json" \
  -d '{
    "clientId": "CLI-001",
    "initialBalance": 0,
    "creditLimit": 50000
  }'
```

**Resposta:**
```json
{
  "accountId": "ACC-1234567890abcdef",
  "clientId": "CLI-001",
  "balance": 0,
  "reservedBalance": 0,
  "creditLimit": 50000,
  "availableBalance": 50000,
  "status": 1
}
```

## Operação de Crédito

```bash
curl -X POST http://localhost:5000/api/transactions \
  -H "Content-Type: application/json" \
  -d '{
    "operation": 1,
    "accountId": "ACC-001",
    "amount": 100000,
    "currency": "BRL",
    "referenceId": "TXN-001",
    "metadata": {
      "description": "Depósito inicial"
    }
  }'
```

**Resposta:**
```json
{
  "transactionId": "TXN-001-PROCESSED",
  "status": "success",
  "balance": 100000,
  "reservedBalance": 0,
  "availableBalance": 100000,
  "timestamp": "2025-01-07T20:05:00Z",
  "errorMessage": null
}
```

## Operação de Débito

```bash
curl -X POST http://localhost:5000/api/transactions \
  -H "Content-Type: application/json" \
  -d '{
    "operation": 2,
    "accountId": "ACC-001",
    "amount": 50000,
    "currency": "BRL",
    "referenceId": "TXN-002"
  }'
```

## Operação de Reserva

```bash
curl -X POST http://localhost:5000/api/transactions \
  -H "Content-Type: application/json" \
  -d '{
    "operation": 3,
    "accountId": "ACC-001",
    "amount": 30000,
    "currency": "BRL",
    "referenceId": "TXN-003"
  }'
```

## Operação de Captura

```bash
curl -X POST http://localhost:5000/api/transactions \
  -H "Content-Type: application/json" \
  -d '{
    "operation": 4,
    "accountId": "ACC-001",
    "amount": 30000,
    "currency": "BRL",
    "referenceId": "TXN-004"
  }'
```

## Operação de Reversão

```bash
curl -X POST http://localhost:5000/api/transactions \
  -H "Content-Type: application/json" \
  -d '{
    "operation": 5,
    "accountId": "ACC-001",
    "amount": 0,
    "currency": "BRL",
    "referenceId": "TXN-005",
    "originalReferenceId": "TXN-001"
  }'
```

## Operação de Transferência

```bash
curl -X POST http://localhost:5000/api/transactions \
  -H "Content-Type: application/json" \
  -d '{
    "operation": 6,
    "accountId": "ACC-001",
    "destinationAccountId": "ACC-002",
    "amount": 20000,
    "currency": "BRL",
    "referenceId": "TXN-006"
  }'
```

## Obter Conta

```bash
curl -X GET http://localhost:5000/api/accounts/ACC-001
```

## Obter Transações de uma Conta

```bash
curl -X GET http://localhost:5000/api/accounts/ACC-001/transactions
```

## Health Check

```bash
curl -X GET http://localhost:5000/health
```

## Métricas Prometheus

```bash
curl -X GET http://localhost:5000/metrics
```

## Testando Idempotência

Envie a mesma requisição duas vezes com o mesmo `referenceId`:

```bash
# Primeira requisição
curl -X POST http://localhost:5000/api/transactions \
  -H "Content-Type: application/json" \
  -d '{
    "operation": 1,
    "accountId": "ACC-001",
    "amount": 1000,
    "currency": "BRL",
    "referenceId": "TXN-DUPLICATE-001"
  }'

# Segunda requisição (deve retornar o mesmo resultado)
curl -X POST http://localhost:5000/api/transactions \
  -H "Content-Type: application/json" \
  -d '{
    "operation": 1,
    "accountId": "ACC-001",
    "amount": 1000,
    "currency": "BRL",
    "referenceId": "TXN-DUPLICATE-001"
  }'
```

A segunda requisição retornará o mesmo resultado da primeira, garantindo idempotência.

